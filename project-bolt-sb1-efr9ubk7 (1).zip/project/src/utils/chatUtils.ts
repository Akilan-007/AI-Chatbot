import { faqData } from '../data/faqData';
import { FAQ } from '../types';

export function findBestMatch(userInput: string): FAQ | null {
  const input = userInput.toLowerCase();
  
  // Direct keyword matching
  for (const faq of faqData) {
    for (const keyword of faq.keywords) {
      if (input.includes(keyword.toLowerCase())) {
        return faq;
      }
    }
  }
  
  // Partial matching for common phrases
  const commonPhrases = [
    { phrases: ['return', 'refund', 'exchange'], category: 'returns' },
    { phrases: ['ship', 'deliver', 'arrival'], category: 'shipping' },
    { phrases: ['size', 'fit', 'measure'], category: 'sizing' },
    { phrases: ['pay', 'payment', 'card'], category: 'payment' },
    { phrases: ['track', 'order', 'status'], category: 'shipping' },
    { phrases: ['cancel', 'stop'], category: 'orders' },
    { phrases: ['contact', 'support', 'help'], category: 'support' },
    { phrases: ['stock', 'available'], category: 'inventory' }
  ];
  
  for (const phrase of commonPhrases) {
    if (phrase.phrases.some(p => input.includes(p))) {
      const categoryMatch = faqData.find(faq => faq.category === phrase.category);
      if (categoryMatch) return categoryMatch;
    }
  }
  
  return null;
}

export function generateBotResponse(userInput: string): string {
  const match = findBestMatch(userInput);
  
  if (match) {
    return match.answer;
  }
  
  return "I apologize, I can only answer questions from our FAQ page. For further assistance, please contact our support team at support@ak.com.";
}

export function getQuickActions(): string[] {
  return [
    "What is your return policy?",
    "How long does shipping take?",
    "How can I track my order?",
    "What payment methods do you accept?"
  ];
}