import React from 'react';
import { getQuickActions } from '../utils/chatUtils';

interface QuickActionsProps {
  onSelectAction: (action: string) => void;
}

export function QuickActions({ onSelectAction }: QuickActionsProps) {
  const actions = getQuickActions();
  
  return (
    <div className="flex flex-wrap gap-2 mb-4">
      {actions.map((action, index) => (
        <button
          key={index}
          onClick={() => onSelectAction(action)}
          className="px-3 py-2 bg-purple-50 text-purple-700 rounded-full text-sm hover:bg-purple-100 transition-colors border border-purple-200"
        >
          {action}
        </button>
      ))}
    </div>
  );
}